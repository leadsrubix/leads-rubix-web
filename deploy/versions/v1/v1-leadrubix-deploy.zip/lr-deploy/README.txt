Leads Rubix — production deploy bundle
======================================

Read HOSTINGER_SHARED.md for the step-by-step Hostinger shared/Business
plan deploy guide (Node.js App + static SPA via .htaccess proxy).

Read HOSTINGER.md if you have a Hostinger Cloud / VPS plan with root
access (systemd + Nginx setup).

Folder layout
-------------
  api/             → upload contents to your Hostinger Node.js App folder
  public_html/     → upload contents to your domain's public_html folder
  HOSTINGER_SHARED.md  → primary guide (read this first)
  HOSTINGER.md         → VPS/Cloud guide (alternative)

Quick checklist
---------------
[ ] Sign up for a Postgres host (Neon recommended)
[ ] Create api.<yourdomain> subdomain in hPanel + install SSL
[ ] Create Node.js App with startup file = index.mjs
[ ] Upload api/* into the Node app folder, rename .env.example → .env, fill it
[ ] Upload public_html/* into your domain's public_html (incl. .htaccess)
[ ] Restart the Node app
[ ] Insert first admin row in Postgres (see Step 7 in HOSTINGER_SHARED.md)
[ ] Visit https://<yourdomain>/admin/login and change the temp password
[ ] Visit /admin/security and enable 2FA

Need help? See the Troubleshooting section at the bottom of HOSTINGER_SHARED.md.
